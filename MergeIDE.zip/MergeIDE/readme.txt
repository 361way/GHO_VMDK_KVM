write by:
http://www.361way.com



i am get it  from  
https://www.virtualbox.org/attachment/wiki/Migrate_Windows/MergeIDE.zip

and you can read this page
http://support.microsoft.com/kb/314082
